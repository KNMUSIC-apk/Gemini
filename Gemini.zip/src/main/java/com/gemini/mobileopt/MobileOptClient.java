package com.gemini.mobileopt;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MobileOptClient implements ClientModInitializer {
    public static final String MOD_ID = "mobileopt";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[MobileOpt] Injecting Android/ARM64 optimizations for Pojav/Zalith...");
        LOGGER.info("[MobileOpt] Particle Culling, Light Throttling, and GC Smoothing active. Sodium pipeline bypassed.");
    }
}

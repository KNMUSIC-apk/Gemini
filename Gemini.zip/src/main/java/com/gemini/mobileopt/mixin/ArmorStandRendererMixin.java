package com.gemini.mobileopt.mixin;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.ArmorStandEntityRenderer;
import net.minecraft.entity.decoration.ArmorStandEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ArmorStandEntityRenderer.class)
public class ArmorStandRendererMixin {
    @Inject(method = "shouldRender(Lnet/minecraft/entity/decoration/ArmorStandEntity;Lnet/minecraft/client/render/Frustum;DDD)Z", 
            at = @At("HEAD"), cancellable = true)
    private void cullDistantArmorStands(ArmorStandEntity entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (!entity.hasCustomName() && entity.squaredDistanceTo(x, y, z) > 1024.0) {
            cir.setReturnValue(false);
        }
    }
}

package com.gemini.mobileopt.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Particle.class)
public abstract class ParticleMixin {
    @Shadow protected double x;
    @Shadow protected double y;
    @Shadow protected double z;
    @Shadow public abstract void markDead();

    @Unique
    private int ageThrottle = 0;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void optimizeParticleTick(CallbackInfo ci) {
        Entity camera = MinecraftClient.getInstance().getCameraEntity();
        if (camera != null) {
            double dx = camera.getX() - this.x;
            double dy = camera.getY() - this.y;
            double dz = camera.getZ() - this.z;
            double distSq = dx * dx + dy * dy + dz * dz;

            if (distSq > 4096.0) {
                this.markDead();
                ci.cancel();
                return;
            }
            
            if (distSq > 576.0) {
                if (ageThrottle++ % 2 != 0) {
                    ci.cancel();
                }
            }
        }
    }
}

package com.gemini.mobileopt.mixin;

import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererLightMixin<T extends Entity> {
    
    @Unique
    private int cachedLight = -1;
    @Unique
    private long lastLightUpdate = 0;
    @Unique
    private BlockPos lastLightPos = null;

    @Inject(method = "getBlockLight", at = @At("HEAD"), cancellable = true)
    private void throttleLightChecks(T entity, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
        long currentTime = System.currentTimeMillis();
        if (lastLightPos != null && lastLightPos.equals(pos) && (currentTime - lastLightUpdate < 250)) {
            cir.setReturnValue(cachedLight);
        }
    }

    @Inject(method = "getBlockLight", at = @At("RETURN"))
    private void cacheLightCheck(T entity, BlockPos pos, CallbackInfoReturnable<Integer> cir) {
        this.cachedLight = cir.getReturnValue();
        this.lastLightPos = pos.toImmutable(); 
        this.lastLightUpdate = System.currentTimeMillis();
    }
}
